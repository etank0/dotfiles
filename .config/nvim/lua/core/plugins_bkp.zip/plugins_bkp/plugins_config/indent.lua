vim.opt.list = true

require("ibl").setup({})
