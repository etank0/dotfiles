require("neo-tree").setup({
	close_if_last_window = true,
	popup_border_style = "rounded",

	-- Window
	window = {
		position = "right",
		width = 35,
	},

	-- Filesystem
	filesystem = {
		follow_current_file = {
			enabled = true,
			leave_dirs_open = false,
		},
	},
})
